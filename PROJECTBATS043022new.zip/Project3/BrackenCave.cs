﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class BrackenCave
    {
        //set Entities here 
        Bat Bat = new Bat();
        Beetle beetle = new Beetle();
        Corn corn = new Corn();

         
    }   
}
