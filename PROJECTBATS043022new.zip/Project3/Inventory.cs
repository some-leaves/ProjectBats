﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class Inventory
    {
        public List<Item> PlayerInventory = new List<Item>()
        {


        };

        public string PrintInventory()
        {
            string Message = "";
            foreach(Item i in PlayerInventory)
            {
                Message += i.ItemName;
            }
            return Message;
        }
    }
}
