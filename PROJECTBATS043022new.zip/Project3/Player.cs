﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    
    public class Player
    {
        public string Name { get; set; }
        public float Money = 3000;
        //  public string inventory { get; set; }

        // public Inventory PlayerInventory;

        public List<Item> PlayerInventory = new List<Item>();
        public Item 

       
    }
}
