﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Project3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Game game = new Game();
        

        public static string LoadTextFromFile(string path) => File.ReadAllText(path);
        public MainWindow()
        {
            InitializeComponent();
        }
       
        private void Inventory_Click(object sender, RoutedEventArgs e)
        {
            TBOutput.Text = "Here is your Inventory :";
            TBOutput.Text =  game.player.PlayerInventory.PrintInventory();
          

        }

        private void Store_Click(object sender, RoutedEventArgs e)
        {
            ShopWindow sw = new ShopWindow(game.player);
            sw.Show();

        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            //Happens before anythign else loads
        }

        private void CreditsBTN_Click(object sender, RoutedEventArgs e)
        {
            TBOutput.Text = "Created By: Kaveonna Gamble, Karen Spriggs, and Grace Anders";
        }

        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            GameWindow gm = new GameWindow(game);
            gm.Show();
        }
    }
}
