﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class Game : IGame
    {
        // Data binding for this class
        // event handlers for when Beetles are getting low & for when bats are getting low & when 
        // set up a warning text block 
        //create a system for the Beetle eating the corn and the bats eating the beetles
        public Player player;
        Store store;
        BrackenCave Cave;
        public int BeetlePopulation = 20000 ;
        public int BatPopulation = 20;
        public int CornPopulation = 5000;


        public List<Entity> Entities = new List<Entity>();
      
        
       // Entities.Add(Corn);
        //Entity.Add(Bat);
        //Entity.Add(Beetle);

      
        public void BeetlesEatsCorn()
        {
            int BP = BeetlePopulation / 5000;
            int AmountEaten = BP * 40;

            CornPopulation -= AmountEaten;
            

        }
        
        public void BatsEatBeetles()
        {
            int bb = BatPopulation;
            int AmountEaten = BatPopulation * 1000;

            BeetlePopulation -= AmountEaten;
        }

        public void UpdatePopulation()
        {
            BeetlesEatsCorn();
            BatsEatBeetles();

        }

        public void StartNewDay()
        {

        }

        public void CheckPopulation()
        {
            if(BeetlePopulation <= 0 || BatPopulation <= 0|| CornPopulation <= 0)
            {
              //  MessageTB.Text = "You lost, L, YBN Better";
            }

        }



        
        
           


  

       







        

        

    }
}
