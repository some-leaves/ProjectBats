﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
   
    public class Entity
    {
        public string Name { get; set; }
        public string Species { get; set; }
        public int EntityQuantity { get; set; }
        public Entity(string name, string species, int entityquantity)
        {
            Name = name;
            Species = species;
            EntityQuantity = entityquantity;
        }

       public Entity()
       {

       }
        
    }
}
