﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project3
{
    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        Game Game;

        bool startgame = true;
        public GameWindow(Game game)
        {
            Game = game;
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

       
        int MaxDays = 7;
        public void StartGame()
        {
           

            while (startgame == true)
            {
                string[] Days = { "Monday","Tuesday","Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

                //loop for days to loop 
                string[] Weather = { };
                for (int i = 0; i <= MaxDays; i++ )
                {
                    //Daytb.Text = ;

                }
              
                // animal 





            }
        }
    }
}
